#include "fila.h"
#include "pilha.h"
#include <stdlib.h>
#include <stdio.h>

bool FilaInicia(Fila* pFila) {
    return ListaInicia(pFila);
}

bool FilaEnfileira(Fila* pFila, Item item) {
    return ListaInsereFinal(pFila, item);
}

bool FilaDesinfeleira(Fila* pFila, Item* pItem) {
    return ListaRetiraPrimeiro(pFila, pItem);
}

bool FilaEhVazia(Fila* pFila) {
    return ListaEhVazia(pFila);
}

void FilaLibera(Fila* pFila) {
    ListaLibera(pFila);
}

bool FilaInverte(Fila* pFila) {
    Pilha pilha;
    PilhaInicia(&pilha);
    while(FilaEhVazia(pFila) == false){
        PilhaPush(&pilha, pFila->cabeca->prox->item);
        FilaDesinfeleira(pFila, &pFila->cabeca->prox->item);
    }
    // printf("\n\n%s\n\n\n", pilha.cabeca->item.nome);
    // while(!PilhaEhVazia(&pilha)){
    //     FilaEnfileira(pFila, pilha.cabeca->prox->item);
    //     PilhaPop(&pilha, &pilha.cabeca->prox->item);
    // }

    return true;
}

void FilaImprime(Fila* pFila) {
    for(Celula* atual=pFila->cabeca->prox; atual != NULL; atual = atual->prox)
        printf("nome:%s\n", atual->item.nome);
    printf("\n");
}