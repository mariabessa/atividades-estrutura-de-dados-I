gcc -c lista.c -Wall
gcc -c pilha.c -Wall
gcc -c fila.c -Wall
gcc -c pratica.c -Wall
gcc lista.o pilha.o fila.o pratica.o -o exe